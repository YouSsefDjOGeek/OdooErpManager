
Odoo ERP Manager is an Android App built on Java & XML , uses PHP Web Service linked to Odoo Postgresql  DBMS
Main features : 
*Scan Order Barcode
* Native Odoo Authentification System 
* Managing Orders on Odoo
* View Orders Details 
* Print Order Bill 
Package Content : 
- Code source 
- Graphic resources 
- UI Design with Adobe XD
Project Availble on My GitHub