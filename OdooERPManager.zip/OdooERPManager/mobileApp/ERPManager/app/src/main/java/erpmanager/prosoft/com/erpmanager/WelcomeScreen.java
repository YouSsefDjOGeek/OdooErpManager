package erpmanager.prosoft.com.erpmanager;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

import static android.app.PendingIntent.getActivity;

public class WelcomeScreen extends AppCompatActivity {
    ImageView OrdersIcon ;
    ImageView ReturnIcon;
    ImageView ProductsIcon;
    ImageView ShippingIcon;
    TextView tvNumberOrders;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome_screen);

    }
    //--- Open Orders Activity
    public void openOrdersAc(View view) {
        OrdersIcon = (ImageView) findViewById(R.id.OrdersIcon);
        tvNumberOrders = (TextView) findViewById(R.id.tvNumberOrders);
        String ordersNumber = tvNumberOrders.getText().toString();
        Intent i;
        i = new Intent(getApplicationContext(), OrdersActivity.class);
        i.putExtra("EXTRA_ordersNumber",ordersNumber);
        startActivity(i);
    }
    //--- Open ReturnActivity Activity
    public void openReturnAc(View view) {
        ReturnIcon = (ImageView) findViewById(R.id.returnIcon);
        Intent i;
        i = new Intent(getApplicationContext(), ReturnActivity.class);
        startActivity(i);
    }
    //--- Open Products Activity
    public void openProductsAc(View view) {
        ProductsIcon = (ImageView) findViewById(R.id.ProductsIcon);
        Intent i;
        i = new Intent(getApplicationContext(), Products.class);
        startActivity(i);
    }


    public void openShippingAc(View view) {
        ShippingIcon = (ImageView) findViewById(R.id.ShippingIcon);
        Intent i;
        i = new Intent(getApplicationContext(), Shipping.class);
        startActivity(i);
    }
}
