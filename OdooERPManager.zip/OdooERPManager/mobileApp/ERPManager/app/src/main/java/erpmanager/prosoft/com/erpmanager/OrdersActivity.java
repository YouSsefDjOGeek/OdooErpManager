package erpmanager.prosoft.com.erpmanager;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.lang.reflect.Array;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class OrdersActivity extends AppCompatActivity {
    TextView tvOrdersTitle ;
    ListView OrdersList;
    OrdersActivity sharedView;
    SessionManager session;
    String[] a;
String[] b;
String[] c;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_orders);
        if(getSupportActionBar()!=null){
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        OrdersList = (ListView) findViewById(R.id.OrdersList);
        this.sharedView = this;
        a=new String[10];
        b=new String[10];
        c=new String[10];
        for (int i=0;i<10;i++)  {
            a[i]="Commande "+i;
            b[i]=""+i;
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy:MM:dd ");
            c[i]=" "+sdf.format(new Date());
        }
        OrdersList.setAdapter(new CustomAdapter(sharedView,a,b,c));

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.premier_page, menu);
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==android.R.id.home){
            finish();
        }
        else{
            SharedPreferences sharedpreferences = getSharedPreferences("AndroidHiveLogin", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedpreferences.edit();
            editor.clear();
            editor.commit();
            Intent intent = new Intent(OrdersActivity.this,LoginScreen.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }
}