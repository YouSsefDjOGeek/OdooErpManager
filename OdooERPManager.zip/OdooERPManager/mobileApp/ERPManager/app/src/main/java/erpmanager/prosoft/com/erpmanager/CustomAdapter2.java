package erpmanager.prosoft.com.erpmanager; /**
 * Created by root on 02/04/16.
 */

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;


public class CustomAdapter2 extends BaseAdapter {
    OrderProducts context;
    Context cont;
    String[] titre;
    String[] id;
    String[] emplacement;
    String[] stock;
    private static LayoutInflater inflater;
    public CustomAdapter2(OrderProducts mainActivity, String[] titre, String[] id, String[] emplacement, String[] stock) {
        // TODO Auto-generated constructor stub
        context = mainActivity;
        this.titre = titre;
        this.id = id;
        this.emplacement = emplacement;
        this.stock = stock;
        inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }
    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return titre.length;
    }

    @Override
    public Object getItem(int position) {
        // TODO Auto-generated method stub
        return position;
    }

    @Override
    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return position;
    }

    public class Holder
    {
        TextView titre;
        TextView id;
        TextView stock;
        TextView emplacement;

    }
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        // TODO Auto-generated method stub
        final Holder holder=new Holder();
        View rowView;
        rowView = inflater.inflate(R.layout.mylist2,null);
        holder.titre=(TextView) rowView.findViewById(R.id.titre);
        holder.titre.setText(titre[position]);
        holder.id=(TextView) rowView.findViewById(R.id.idproduit);
        holder.id.setText(id[position]);
        holder.emplacement=(TextView) rowView.findViewById(R.id.emplacement);
        holder.emplacement.setText(emplacement[position]);
       holder.stock=(TextView) rowView.findViewById(R.id.stockrest);
        holder.stock.setText(stock[position]);
        rowView.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
               Toast.makeText(context,"commande"+position,Toast.LENGTH_LONG).show();
              Intent intent = new Intent(context.getApplicationContext(),ScanCaisse.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
                context.getApplicationContext().startActivity(intent);
                // TODO Auto-generated method stub
            }
        });
        return rowView;
    }
}