package erpmanager.prosoft.com.erpmanager;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ListView;

import java.text.SimpleDateFormat;
import java.util.Date;

public class OrderProducts extends AppCompatActivity {
    OrderProducts sharedView;
    ListView OrdersList;
    String[] a;
    String[] b;
    String[] c;
    String[] d;
    SessionManager session;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_products);
        if(getSupportActionBar()!=null){
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        OrdersList = (ListView) findViewById(R.id.listproduct);
        this.sharedView = this;
        a=new String[10];
        b=new String[10];
        c=new String[10];
        d=new String[10];
        for (int i=0;i<10;i++)  {
            a[i]="produit "+i;
            b[i]="0000"+i;
            c[i]=" ABCD"+i;
            d[i]="0"+i;
        }
        OrdersList.setAdapter(new CustomAdapter2(sharedView,a,b,c,d));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.premier_page, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==android.R.id.home){
            finish();
        }
        else{
            SharedPreferences sharedpreferences = getSharedPreferences("AndroidHiveLogin", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedpreferences.edit();
            editor.clear();
            editor.commit();
            Intent intent = new Intent(OrderProducts.this,LoginScreen.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }
}