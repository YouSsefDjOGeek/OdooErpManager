<?php
require_once('ripcord.php');
$url = "http://localhost:8069";
$db = "myCompany";
$username = "admin";
$password = 'admin';

$common = ripcord::client("$url/xmlrpc/2/common");
$common->version();
$uid = $common->authenticate($db, $username, $password, array());

$models = ripcord::client("$url/xmlrpc/2/object");
$res=$models->execute_kw($db, $uid, $password,
    'terminalusers', 'search_read', array(
  array(
   ),
), array(
  'fields' => array('passwd','terminal_username')));

echo json_encode($res,JSON_UNESCAPED_UNICODE);

?>